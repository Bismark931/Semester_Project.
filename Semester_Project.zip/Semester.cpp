#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;
class students {
class studentsDatabase {
private:
	vector<students> students;
	string filename;
	
public:
	studentsDatabase (const string& fname) :
		filename(fname) {
		loadfromFile();
	}
     "voidadd" studentDatabase(const student& student)
{
students.push_back(studnts);
savetofile();
}
void displayAllstudentss() {
	for (const auto& students :students)
{
	students.display();
	cout <<"----------"<<
	endl;
}
}
//Add method for editing,delating,and users authentication here
void loadfromfile(){
	ifstream file(filename);
	if(file.is_open()) {
	students students;
	while (file>>student)



	return (0);
}