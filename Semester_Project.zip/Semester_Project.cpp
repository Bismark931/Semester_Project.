#include <iostream>
#include <fstream>
#include <vector>
#include <string>

class Student {
public:
    std::string name;
    int id;
    // Other student attributes

    Student(const std::string& n, int i) : name(n), id(i) {}

    void displayInfo() const {
        std::cout << "Name: " << name << "\nID: " << id << std::endl;
    }
};

class Database {
private:
    std::vector<Student> students;
    const std::string filename = "students.txt";

    void loadDatabase() {
        std::ifstream inputFile(filename);
        if (!inputFile) {
            std::cerr << "Error opening file." << std::endl;
            return;
        }

        Student student("", 0);
        while (inputFile >> student.name >> student.id) {
            students.push_back(student);
        }

        inputFile.close();
    }

    void saveDatabase() {
        std::ofstream outputFile(filename);
        if (!outputFile) {
            std::cerr << "Error opening file." << std::endl;
            return;
        }

        for (const auto& student : students) {
            outputFile << student.name << " " << student.id << std::endl;
        }

        outputFile.close();
    }

public:
    Database() {
        loadDatabase();
    }

    ~Database() {
        saveDatabase();
    }

    void addStudent(const Student& student) {
        students.push_back(student);
    }

    void displayStudents() const {
        for (const auto& student : students) {
            student.displayInfo();
            std::cout << "------------------------\n";
        }
    }
};

int main() {
    Database database;
    int choice;

    while (true) {
        std::cout << "1. Add Student\n";
        std::cout << "2. Display Students\n";
        std::cout << "3. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        if (choice == 1) {
            std::string name;
            int id;

            std::cout << "Enter student name: ";
            std::cin >> name;
            std::cout << "Enter student ID: ";
            std::cin >> id;

            Student student(name, id);
            database.addStudent(student);
        } else if (choice == 2) {
            database.displayStudents();
        } else if (choice == 3) {
            break;
        }
    }

    return 0;
}